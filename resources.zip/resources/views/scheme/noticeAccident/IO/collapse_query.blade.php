<div class="row">
    <div class="col-sm-12">
            <div class="card">
            <form class="form">     
                    <div class="row">
                            <div class="col-sm-12">
                                    <div class="card">
                                    <form class="form">
                                            <div class="card m-b-0">
                                                    <div class="card-header" role="tab" id="headingQuery">
                                                            <h6 class="mb-0">                           
                                                                    <a class="link" data-toggle="collapse" data-parent="#accordion2" href="#collapseQuery" aria-expanded="false" aria-controls="collapseQuery">
                                                                            <h4 class="card-title"><i class="fa fa-plus"></i>Query and Opinion</h4> </a>
                                                            </h6>
                                                    </div>
                                                    <div id="collapseQuery" class="collapse" role="tabpanel" aria-labelledby="headingQuery">
                                                            <div class="card-body">@include('scheme.noticeAccident.SCO.query_opinion')</div>
                                                    </div>
                                            </div>
                                             {{-- <div class="card m-b-0">
                                                    <div class="card-header" role="tab" id="headingMedical">
                                                            <h6 class="mb-0">                           
                                                                    <a class="link" data-toggle="collapse" data-parent="#accordion2" href="#collapseMedical" aria-expanded="false" aria-controls="collapseMedical">
                                                                            <h4 class="card-title"><i class="fa fa-plus"></i> @lang('scheme/index.attr.medical_opinion') </h4> </a>
                                                            </h6>
                                                    </div>
                                                    <div id="collapseMedical" class="collapse" role="tabpanel" aria-labelledby="headingMedical">
                                                            <div class="card-body">@include('scheme.noticeAccident.IO.queryOpinion')</div>
                                                    </div>
                                            </div> --}}
                                             {{-- <div class="card m-b-0">
                                                    <div class="card-header" role="tab" id="headingLegal">
                                                            <h6 class="mb-0">                           
                                                                    <a class="link" data-toggle="collapse" data-parent="#accordion2" href="#collapseLegal" aria-expanded="false" aria-controls="collapseLegal">
                                                                            <h4 class="card-title"><i class="fa fa-plus"></i> @lang('scheme/index.attr.legal_opinion') </h4> </a>
                                                            </h6>
                                                    </div>
                                                    <div id="collapseLegal" class="collapse" role="tabpanel" aria-labelledby="headingLegal">
                                                            <div class="card-body">@include('scheme.noticeAccident.IO.queryOpinion')</div>
                                                    </div>
                                            </div>
                                             <div class="card m-b-0">
                                                    <div class="card-header" role="tab" id="headingPPN">
                                                            <h6 class="mb-0">                           
                                                                    <a class="link" data-toggle="collapse" data-parent="#accordion2" href="#collapsePPN" aria-expanded="false" aria-controls="collapsePPN">
                                                                            <h4 class="card-title"><i class="fa fa-plus"></i> @lang('scheme/index.attr.ppn_opinion') </h4> </a>
                                                            </h6>
                                                    </div>
                                                    <div id="collapsePPN" class="collapse" role="tabpanel" aria-labelledby="headingPPN">
                                                            <div class="card-body">@include('scheme.noticeAccident.IO.queryOpinion')</div>
                                                    </div>
                                            </div>
                                            <div class="card m-b-0">
                                                    <div class="card-header" role="tab" id="headingARO">
                                                            <h6 class="mb-0">                           
                                                                    <a class="link" data-toggle="collapse" data-parent="#accordion2" href="#collapseARO" aria-expanded="false" aria-controls="collapseARO">
                                                                            <h4 class="card-title"><i class="fa fa-plus"></i> @lang('scheme/index.attr.aro_opinion') </h4> </a>
                                                            </h6>
                                                    </div>
                                                    <div id="collapseARO" class="collapse" role="tabpanel" aria-labelledby="headingARO">
                                                            <div class="card-body">@include('scheme.noticeAccident.IO.queryOpinion')</div>
                                                    </div>
                                            </div> --}}
                                    </form>
                                    </div>
                            </div>
                    </div>
            </form>
            </div>
    </div>
</div>