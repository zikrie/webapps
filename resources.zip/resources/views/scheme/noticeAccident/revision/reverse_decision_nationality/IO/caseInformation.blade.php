<div class="tab-pane p-20 active" id="" role="tabpanel">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="#">
                        <div class="form-body">
                            
                           
                           

                          
<!-- 
                            <div class="row p-t-20">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <table class="table table-sm table-bordered" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <th><b>Identification Type</b></th>
                                                    <th><b>Identification No.</b></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>New IC</td>
                                                    <td>90082014530</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div> -->

                            

                            <div class="row p-t-20">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Identification No.</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Notice ID</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Revision Type</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>

                            <div class="row p-t-20">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label">Revision Reason</label>
                                        <textarea type="text" id=""  value="" class="form-control" ></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="row p-t-20">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Source</label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">New Info</option>
                                            <option value="">Aduan</option>
                                            <option value="">JRKS</option>
                                            <option value="">Fraud</option>
                                            <option value="">Inspection collection contribution module</option>
                                            <option value="">Others</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Nationality</label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Citizen</option>
                                            <option value="">Non Citizen</option>
                                            <option value="">Permanent Citizent</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Employer Under the Act</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Date Employer Not Under the Act</label>
                                        <input type="date" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>

                          
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    
    
