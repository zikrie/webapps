<div class="tab-pane p-20 active" id="" role="tabpanel">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="#">
                        <div class="form-body">
                            
                           
                            <div class="row p-t-20">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Item</label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Masa Kemalangan</option>
                                            <option value="">Tempat Kemalangan</option>
                                            <option value="">Tarikh Kemalangan</option>
                                            <option value="">Jenis Kecederaan</option>
                                            <option value="">Bagaimana kemalangan Berlaku</option>
                                            <option value="">Tarikh Kematian</option>
                                            <option value="">Sebab Kematian</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Item</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>
                            <div class="row p-t-20">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label">Review</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>
                            <div class="row p-t-20">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Review By</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Investigation Date</label>
                                        <input type="date" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Changes Data</label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Masa Kemalangan</option>
                                            <option value="">Tempat Kemalangan</option>
                                            <option value="">Tarikh Kemalangan</option>
                                            <option value="">Jenis Kecederaan</option>
                                            <option value="">Bagaimana kemalangan Berlaku</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Finding Data</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">finding Supporting document</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Justification/Finding</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>
                               
                           

                          
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
