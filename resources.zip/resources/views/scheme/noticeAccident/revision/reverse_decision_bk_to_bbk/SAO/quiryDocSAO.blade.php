<div class="tab-pane p-20 active" id="" role="tabpanel">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="#">
                        <div class="form-body">
                            
                           
                            <div class="row p-t-20">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label"> Quiry Information</label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Maklumat Tidak Lengkap</option>
                                            <option value="">Maklumat Gaji</option>
                                            <option value="">Laporan Polis</option>
                                            <option value="">Borang J</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Letter generate date</label>
                                        <input type="date" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Route</label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">SAO</option>
                                            <option value="">IO</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Opinion Type</label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Pengesahan MC / kecederaan berkaitan kemalangan (sebelum JD)</option>
                                            <option value="">Pengesahan kematian berkaitan dengan kemalangan (sebelum JD)</option>
                                            <option value="">Pengesahan Rujukan MMI (180 hari) (sebelum JD)</option>
                                            <option value="">Kewajaran taksiran (selepas JD)</option>
                                            <option value="">Kewajaran keputusan (selepas JD)</option>
                                            <option value="">Kewajaran ELS (selepas JD)</option>
                                            <option value="">Seksyen 96</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">MS Opinion</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>
                               
                           

                          
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
