<div class="tab-pane p-20 active" id="" role="tabpanel">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="#">
                        <div class="form-body">

                            <div class="row p-t-20">
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Bank Account </label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Bank Name</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Bank Account No</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Reason(if no bank account)</label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Bankrupt</option>
                                            <option value="">Residing Overseas</option>
                                            <option value="">Permanent Representative</option>
                                            <option value="">No IC</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Account Type </label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Saving</option>
                                            <option value="">Current</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Swift Code</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">BSB Code</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>

                            <div class="row p-t-20">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label">Overseas Bank Address</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                         <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>

                           

                          
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    
    