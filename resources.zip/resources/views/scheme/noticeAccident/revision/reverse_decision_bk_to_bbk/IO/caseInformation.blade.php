<div class="tab-pane p-20 active" id="" role="tabpanel">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="#">
                        <div class="form-body">
                            
                           
                            <div class="row p-t-20">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Notice ID</label><span class="required">*</span>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Revision Type</label><span class="required">*</span>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>

                            <div class="row p-t-20">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Revision Reason</label><span class="required">*</span>
                                        <textarea type="text" id=""  value="" class="form-control" ></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="row p-t-20">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Received Revision Notice Date</label><span class="required">*</span>
                                        <input type="date" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Source</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row p-t-20">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Remarks</label>
                                        <textarea type="text" id=""  value="" class="form-control" ></textarea> 
                                    </div>
                                </div>
                            </div>

                           

                          
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
