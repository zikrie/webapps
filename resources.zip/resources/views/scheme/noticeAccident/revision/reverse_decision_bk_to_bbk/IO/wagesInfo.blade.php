<div class="tab-pane p-20 active" id="" role="tabpanel">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="#">
                        <div class="form-body">

                            <div class="row p-t-20">
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Employmment Start Date</label>
                                        <input type="date" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Employment End Date</label>
                                        <input type="date" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Do Wage Paid on Day Accident</label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Yes</option>
                                            <option value="">No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Month of Contribution</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Year </label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Month </label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Wages (RM) </label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Contribution (RM) </label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>
                                
                            <div class="row p-t-20">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Reason From SCO </label>
                                        <textarea type="text" id=""  value="" class="form-control" ></textarea> 
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Remark From SCO </label>
                                        <textarea type="text" id=""  value="" class="form-control" ></textarea> 
                                    </div>
                                </div>
                            </div>

                            <div class="row p-t-20">
                               
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Minimum Wages From SCO </label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Accept from IO </label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>
                                

                            <div class="row p-t-20">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Reason from IO </label>
                                        <textarea type="text" id=""  value="" class="form-control" ></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Remark from IO </label>
                                        <textarea type="text" id=""  value="" class="form-control" ></textarea>
                                    </div>
                                </div>
                            </div>
                                

                            <div class="row p-t-20">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Minimum Wages from IO </label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Accept </label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>
                                

                            <div class="row p-t-20">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Reason </label>
                                        <textarea type="text" id=""  value="" class="form-control" ></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Remark </label>
                                        <textarea type="text" id=""  value="" class="form-control" ></textarea>
                                    </div>
                                </div>
                            </div>
                                

                            <div class="row p-t-20">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Minimum Wages </label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>

                           

                          
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    
    