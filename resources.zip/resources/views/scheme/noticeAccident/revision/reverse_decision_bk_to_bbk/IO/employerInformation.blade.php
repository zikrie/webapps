<div class="tab-pane p-20 active" id="" role="tabpanel">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="#">
                        <div class="form-body">

                            <div class="row p-t-20">
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Wages Type </label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Current</option>
                                            <option value="">Previous</option>
                                            <option value="">Multiple</option>
                                            <option value="">Similar Worker</option>
                                            <option value="">Similar Industry</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Employer Code</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>
                            <div class="row p-t-20">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label">Employer Name</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row p-t-20">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Employer Type</label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Badan Berkanun</option>
                                            <option value="">Swasta</option>
                                            <option value="">Kerajaan</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row p-t-20">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label">Address </label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                         <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                         <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>

                            <div class="row p-t-20">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Postcode</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">City</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">State</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Telephone No.</label>
                                         <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Fax No.</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">E-Mail</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>

                           

                          
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    
    