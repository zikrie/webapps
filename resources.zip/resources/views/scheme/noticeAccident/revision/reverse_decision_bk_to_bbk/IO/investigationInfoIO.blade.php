<div class="tab-pane p-20 active" id="" role="tabpanel">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="#">
                        <div class="form-body">
                            
                           
                            <div class="row p-t-20">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Investigation Date</label>
                                        <input type="date" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Whether the insured person is an employee under the SOCSO Act? </label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Yes</option>
                                            <option value="">No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Whether the SOCSO Act applies to this industry? </label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Yes</option>
                                            <option value="">No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Whether the personal injury is caused by an accident or an OD? </label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Yes</option>
                                            <option value="">No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Whether the accident or OD is in the course of his/her employment? </label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Yes</option>
                                            <option value="">No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Whether the accident or the OD arised out of his employment? </label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Yes</option>
                                            <option value="">No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">IO Recommendation </label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Bencana Kerja</option>
                                            <option value="">Bukan Bencana Kerja</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                               
                           

                          
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
