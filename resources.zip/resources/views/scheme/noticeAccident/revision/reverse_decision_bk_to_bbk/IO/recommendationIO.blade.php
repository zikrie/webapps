<div class="tab-pane p-20 active" id="" role="tabpanel">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="#">
                        <div class="form-body">
                            
                           
                            <div class="row p-t-20">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">  @lang('form/scheme.general.collapse.IO_recommendation.recommendation')</label>
                                        <select class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="">Syor</option>
                                            <option value="">Tidak Syor</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">@lang('form/scheme.general.collapse.IO_recommendation.recommended_by')</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">@lang('form/scheme.general.collapse.IO_recommendation.recommended_date')</label>
                                        <input type="date" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>
                               
                           

                          
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
