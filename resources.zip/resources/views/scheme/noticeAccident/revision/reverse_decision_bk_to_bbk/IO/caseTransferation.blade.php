<div class="tab-pane p-20 active" id="" role="tabpanel">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="#">
                        <div class="form-body">

                            <div class="row p-t-20">
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Transfer</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Origin</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="control-label">Current</label>
                                        <input type="text" id="" class="form-control" >
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row p-t-20">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Remarks</label>
                                        <textarea type="text" id=""  value="" class="form-control" ></textarea> 
                                    </div>
                                </div>
                            </div>

                           

                          
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    
    