<link href="{{ asset('/css/style.css') }}" rel="stylesheet" type="text/css" />
<link href="/PERKESO_UI/assets/node_modules/morrisjs/morris.css" rel="stylesheet">
<!-- Vector CSS -->
<link href="/PERKESO_UI/assets/node_modules/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
<!--c3 CSS -->
<link href="/PERKESO_UI/horizontal-nav-fullwidth/dist/css/pages/easy-pie-chart.css" rel="stylesheet">
<!-- Custom CSS -->
<link href="/PERKESO_UI/horizontal-nav-fullwidth/dist/css/style.min.css" rel="stylesheet">
<!-- Dashboard 1 Page CSS -->
<link href="/PERKESO_UI/horizontal-nav-fullwidth/dist/css/pages/dashboard2.css" rel="stylesheet">
<link href="/PERKESO_UI/horizontal-nav-fullwidth/dist/css/pages/error-pages.css" rel="stylesheet">

<link rel="stylesheet" href="/PERKESO_UI/assets/node_modules/dropify/dist/css/dropify.min.css">

<link href="/PERKESO_UI/assets/node_modules/clockpicker/dist/jquery-clockpicker.min.css" rel="stylesheet">
<link href="/PERKESO_UI/assets/node_modules/timepicker/bootstrap-timepicker.min.css" rel="stylesheet">
<link href="/PERKESO_UI/assets/node_modules/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
<link href="/PERKESO_UI/assets/node_modules/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">
<!-- Color picker plugins css -->
<link href="/PERKESO_UI/assets/node_modules/jquery-asColorPicker-master/dist/css/asColorPicker.css" rel="stylesheet">
<!-- Date picker plugins css -->
<link href="/PERKESO_UI/assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
<!-- Custom CSS -->
<link href="/PERKESO_UI/assets/node_modules/wizard/steps.css" rel="stylesheet">
<!--alerts CSS -->
<link href="/PERKESO_UI/assets/node_modules/sweetalert/sweetalert.css" rel="stylesheet" type="text/css">
<!-- Custom CSS -->
<link href="/PERKESO_UI/horizontal-nav-fullwidth/dist/css/style.min.css" rel="stylesheet">

<link href="/PERKESO_UI/assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
    <link href="/PERKESO_UI/assets/node_modules/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" />
    <link href="/PERKESO_UI/assets/node_modules/switchery/dist/switchery.min.css" rel="stylesheet" />
    <link href="/PERKESO_UI/assets/node_modules/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
    <link href="/PERKESO_UI/assets/node_modules/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
    <link href="/PERKESO_UI/assets/node_modules/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
    <link href="/PERKESO_UI/assets/node_modules/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" />
   
    <!-- page css -->
 

<link href="{{ asset('/css/overrides.css') }}" rel="stylesheet" type="text/css" />