<?php

return [
          'logout' => 'Keluar',
          'profile' => 'Profil',

];
