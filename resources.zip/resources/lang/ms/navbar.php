<?php

// Contains menu after app section for every role

return [

	'home' => 'My BeAMS',
	'new_claim' => 'Tuntutan Baru',
	'query' => 'Pertanyaan',
          'pending' => 'Menunggu',
          'date' => 'Tarikh',
	'scheme_ref_no' => 'No. Rujukan Skim',
	'id_no' => 'No. Pengenalan',
	
];