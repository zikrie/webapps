<?php

// For Personal info

return [

          'address' => 'Address',
          'postcode' => 'Postcode',
          'city' => 'City',
          'state' => 'State',
          'house_no' => 'House Telephone No.',
          'tel_no' => 'Telephone No',
          'mobile_no' => 'Mobile No',
          'fax_no' => 'Fax No.',
          'email' => 'Email Address',
          'nationality' => 'Nationality',
	
];