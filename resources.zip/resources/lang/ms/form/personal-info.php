<?php

// For Personal info

return [

          'name' => 'Name',
          'id_no' => 'Identification No',
          'id_type' => 'Identification Type',
          'race' => 'Race',
          'date_birth' => 'Date of Birth',
          'gender' => 'Gender',
          'occupation_form34' => 'Occupation (Based on Form 34)',
          'occupation' => 'Occupation',
          'sub_occupation' => 'Sub Occupation',
          'sub_occupationlist' => 'Sub Occupation List',
	
];