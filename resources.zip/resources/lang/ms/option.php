<?php

// For selection or option (dropdown/checkbox etc) that are not from reftable

return [

		'please_select' => 'Sila Pilih',
		'yes' => 'Ya',
		'no' => 'Tidak',
		'both' => 'Kedua-duanya',

		'pencen_ilat' => 'Pencen Ilat',
		'huk' => 'Hilang Upaya Kekal',
	
];