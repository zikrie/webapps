<?php
 
return [

	'title' => 'WAKIL MAJIKAN',

    'attr' => [
    	
        'details' => 'Saya memperakui bahawa sepanjang pengetahuan dan kepercayaan saya bahawa semua butiran yang dinyatakan adalah benar.',
        'sign' => 'Tandatangan majikan / wakil majikan yang diberi kuasa',
        'name' => 'Nama',
        'designation' => 'Jawatan',
        'date' => 'Tarikh',
        'no_sign' => 'Tandatangan tidak diperlukan sekiranya borang ini dihantar melalui medium elektronik tertakluk kepada pengesahan oleh PERKESO.',
        
    ],

    'save' => 'SIMPAN',
    'cancel' => 'BATAL',
    'clear' => 'PADAM',
    'submit' => 'HANTAR',
 
];