<?php
 
return [

	'title' => 'PILIHAN PEJABAT PERKESO UNTUK BERURUSAN ',

    'attr' => [
    	
        'city' => 'Bandar',
        'state' => 'Negeri',
        'city_origin' => ' Bandar (asal)',
        'state_origin' => 'Negeri (asal)',
        'details' => 'Jika ada perubahan pejabat',
        
    ],

    'save' => 'SIMPAN',
    'cancel' => 'BATAL',
    'clear' => 'PADAM',
 
];