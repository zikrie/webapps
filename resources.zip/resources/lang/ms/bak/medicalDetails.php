<?php
 
return [

	'title' => 'Butiran Cuti Sakit',

    'attr' => [
    	'nameAddress_clinic' => 'Nama & alamat klinik yang memberikan rawatan',
        'start_mc' => 'Tarikh Mula Cuti Sakit',
        'end_mc' => 'Tarikh Akhir Cuti Sakit',
        'mc_status' => 'Status Cuti Sakit',
        'total_days' => 'Jumlah Hari',
        'wages_mc' => 'Bekerja dan dibayar gaji dalam tempoh mc',
        'start_date' => 'Tarikh mula  hadir kerja',
        'end_date' => 'Tarikh akhir  hadir kerja',
        'days_work' => 'jumlah hari hadir kerja',
        'status' => 'Status Hadir Kerja',
        'yes' => 'Ya',
        'no' => 'Tidak', 

    ],

    'save' => 'SIMPAN',
    'cancel' => 'BATAL',
    'clear' => 'PADAM',
    'choose' => 'Sila Pilih',
 
];