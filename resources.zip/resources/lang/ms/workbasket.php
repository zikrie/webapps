<?php

// For workbasket

return [

	'task' => 'Peti Tugasan',
	'draft' => 'Draf',
	'query' => 'Pertanyaan',
          'pending' => 'Menunggu',
          'date' => 'Tarikh',
	'scheme_ref_no' => 'No. Rujukan Skim',
	'id_no' => 'No. Pengenalan',
	
];