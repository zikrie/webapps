<?php

// For button on every page for all modules

return [

	'save' => 'SIMPAN',
	'save_next' => 'SIMPAN & SETERUSNYA',
	'cancel' => 'BATAL',
	'next' => 'SETERUSNYA',
	'previous' => 'SEBELUMNYA',
	'reset' => 'SET SEMULA',
	'back' => 'KEMBALI',
	'close' => 'TUTUP',
	'ok' => 'OK',
	'adddoc' => 'TAMBAH DOKUMEN',
	
];