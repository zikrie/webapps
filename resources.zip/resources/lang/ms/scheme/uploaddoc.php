<?php
 
return [

'title' => 'Upload Document',

    'attr' => [
    
        'docdesc' => 'Document Description',
        'docpath' => 'Document Path',
        'recvdate' => 'Received Date',
        'uploaddate' => 'Upload Date',
        'certify' => 'Certify True',
        'source' => 'Source of Documents',
        'doctype' => 'Document Type',
        'verify' => 'Document Verification',
        'view' => 'View',
        'delete' => 'Delete',
        'remove' => 'Remove',
        'date' => 'Date',
        'doc_desc' => 'Document Description',
        'generated_date' => 'Generated Date',
        
    ],

    'uploadall' => 'UPLOAD ALL',
    'adddoc' => 'ADD DOCUMENT',
    'clear' => 'CLEAR',
 
];
