<?php
 
return [

	'title' => 'Dependant Study Information',

    'attr' => [
    	
        'study_start_date' => 'Study Start Date',
        'study_end_date' => 'Expected Study End Date',
        'status' => 'Status',
        'edu_level' => 'Education Level',
		'pls_specify' => 'Please  Specify',
		'course_name' => 'Course Name',
        'inst_univer_name' => 'Institute/University Name',		  
        
    ],

    'save' => 'SAVE',
    'cancel' => 'CANCEL',
    'clear' => 'CLEAR',
 
];
