<?php
 
return [

	'title' => 'Perakuan Majikan',

    'attr' => [
    	
        'details' => 'Saya memperakui bahawa sepanjang pengetahuan dan kepercayaan saya bahawa semua butiran yang dinyatakan adalah benar.',
        'sign' => 'Tandatangan',
        'name' => 'Nama',
        'designation' => 'Jawatan',
        'date' => 'Tarikh',
        'no_sign' => 'Tandatangan tidak diperlukan sekiranya borang ini dihantar melalui medium elektronik tertakluk kepada pengesahan oleh PERKESO.',
        
    ],

    'save' => 'Simpan',
    'cancel' => 'Batal',
    'clear' => 'Padam',
    'submit' => 'Hantar',
 
];