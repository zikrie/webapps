<?php
 
return [

	'title' => 'Maklumat Pengesahan Belajar',

    'attr' => [
    	
        'study_start_date' => 'Tarikh Mula Belajar',
        'study_end_date' => 'Tarikh Dijangka Tamat Belajar',
        'status' => 'Status',
        'edu_level' => 'Tahap Pendidikan',
		'pls_specify' => 'Sila Nyatakan',
		'course_name' => 'Nama Kursus',
        'inst_univer_name' => 'Nama Institut/Universiti',		  
        
    ],

    'save' => 'Simpan',
    'cancel' => 'Batal',
    'clear' => 'Padam',
 
];

