<?php

return [

	'profile' => 'Profile Saya',
	'balance' => 'Baki Saya',
	'inbox' => 'Peti',
	'account' => 'Tetapan Akaun',
	'logout' => 'Log Keluar'
	
];