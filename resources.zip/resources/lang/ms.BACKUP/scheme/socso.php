<?php
 
return [

	'title' => 'Pilihan Pejabat PERKESO ',

    'attr' => [
    	
        'city' => 'Bandar',
        'state' => 'Negeri',
        'city_origin' => 'Bandar (Origin)',
        'state_origin' => 'Negeri (Origin)',
        'details' => 'Jika ada perubahan pejabat',
        
    ],

    'save' => 'Simpan',
    'cancel' => 'Batal',
    'clear' => 'Padam',
 
];