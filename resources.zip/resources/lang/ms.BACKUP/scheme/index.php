<?php
 
return [

    'attr' => [

    	'accident_notice' => 'Notis Kemalangan',
        'od_notice' => 'Notis Penyakit Khidmat',
        'invalidity_notice' => 'Notis Keilatan',
        'death_notice' => 'Notis Kematian',
        'insured_details' => 'Maklumat OB',
        'employer_details' => 'Maklumat Majikan',
        'wages_details' => 'Maklumat Gaji',
        'death_details' => 'Maklumat Kematian',
        'invalidity_details' => 'Maklumat Keilatan',
        'pension_details' => 'Maklumat Pencen',
        'od_details' => 'Maklumat Penyakit Khidmat',
        'accident_details' => 'Maklumat Kemalangan',
        'medical_details' => 'Maklumat Cuti Sakit ',
        'preferred_socso' => 'Pilihan Pejabat Perkeso',
        'certificate' => 'Perakuan Majikan',
        'confirmation' => 'Pengesahan',
        'permanent_representative' => 'Wakil Tetap',
        'bank_information' => 'Maklumat Bank',
        'dependant_profiles' => 'Profil Orang Tanggungan',
        'upload_documents' => 'Muat Naik Dokumen',
        'od_information' => 'Maklumat Penyakit Khidmat',
        'employer_history' => 'Maklumat Majikan Terdahulu',
    ],

 
];