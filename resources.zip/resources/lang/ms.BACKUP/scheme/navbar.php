<?php
 
return [

	'new_claim' => 'Tuntutan Baru',
	'upload_doc' => 'Muat Naik Dokumen',
	'home' => 'Halaman Utama',
	'ob_profile' => 'Profil OB',
	'claim_info' => 'Maklumat Tuntutan',
 
];