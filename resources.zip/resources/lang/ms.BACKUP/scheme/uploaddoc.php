<?php
 
return [

	'title' => 'Upload Document',

    'attr' => [
    	
        'docdesc' => 'Penerangan Dokumen',
        'docpath' => 'Laluan Dokumen',
        'view' => 'Lihat',
        'delete' => 'Padam',
        'remove' => 'Keluarkan',
        
    ],

    'uploadall' => 'Muat Naik Semua',
    'adddoc' => 'Tambah Dokumen',
    'clear' => 'Padam',
 
];