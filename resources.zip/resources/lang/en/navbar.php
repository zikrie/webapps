<?php

// Contains menu after app section for every role

return [

	'home' => 'My BeAMS',
	'new_claim' => 'New Claim',
	'query' => 'Query',
          'pending' => 'Pending',
          'date' => 'Date',
	'scheme_ref_no' => 'Scheme Ref No',
	'id_no' => 'ID No',
	
];