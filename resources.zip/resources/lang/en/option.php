<?php

// For selection or option (dropdown/checkbox etc) that are not from reftable

return [

		'please_select' => 'Please Select',
		'yes' => 'Yes',
		'no' => 'No',
		'both' => 'Both',

		'pencen_ilat' => 'Invalidity Pension',
		'huk' => 'Permanent Disability',
	
];