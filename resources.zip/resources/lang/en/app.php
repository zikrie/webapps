<?php

return [
          'logout' => 'Logout',
          'profile' => 'Profile',

];
