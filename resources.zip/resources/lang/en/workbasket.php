<?php

// For workbasket

return [

	'task' => 'Task Inbox',
	'draft' => 'Draft',
	'query' => 'Query',
          'pending' => 'Pending',
          'date' => 'Date',
	'scheme_ref_no' => 'Scheme Ref No',
	'id_no' => 'Identification No',
	
];