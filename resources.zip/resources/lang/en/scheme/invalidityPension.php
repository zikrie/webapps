<?php
 
return [

	'title' => 'Invalidity Pension Payment History',
    'attr' => [
    	
        'payment_hist' => 'Payment History',
        'els' => 'ELS (Y/N)',
        'notice_date' => 'Notice Date ',
        'debtor' => 'Debtor Information',
        
    ],

    'save' => 'Save',
    'cancel' => 'Cancel',
    'clear' => 'Clear',
 
];