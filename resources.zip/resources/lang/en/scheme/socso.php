<?php
 
return [

	'title' => 'SOCSO Office ',

    'attr' => [
    	
        'city' => 'City',
        'state' => 'State',
        'city_origin' => ' City (Origin)',
        'state_origin' => 'State (Origin)',
        'details' => 'If there is a change of office',
        'registered_branch' => 'Registered Branch',
        'registerBranch' => 'Registered Branch',
        'preferred_socso_branch' => 'Preferred SOCSO Branch',
        
    ],

    'save' => 'SAVE',
    'cancel' => 'CANCEL',
    'clear' => 'CLEAR',
 
];