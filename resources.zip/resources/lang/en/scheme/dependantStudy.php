<?php
 
return [

	'title' => 'Education Information',

    'attr' => [
    	
        'study_start_date' => 'Start Date',
        'study_end_date' => 'End Date',
        'status' => 'Status',
        'edu_level' => 'Education Level',
		'pls_specify' => 'Please  Specify',
		'course_name' => 'Course Name',
        'inst_univer_name' => 'Institution',		  
        
    ],

    'save' => 'SAVE',
    'cancel' => 'CANCEL',
    'clear' => 'CLEAR',
 
];
