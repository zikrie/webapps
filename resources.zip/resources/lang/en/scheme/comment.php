<?php
 
return [

	'title' => 'Comment',

    'attr' => [
    	
        'comment_by' => 'Comment by',
        'comment_date' => 'Comment Date',
        'comment_desc' => 'Comment',
        
        
    ],

    'save' => 'Save',
    'cancel' => 'Cancel',
    'clear' => 'Clear',
    'submit' => 'Submit',
 
];