<?php
 
return [

     'title' => 'Overpayment Information',

     'attr' => [
    	
        'reason' => 'Overpayment Reason',
        "debtor_id" => "Debtor's ID",
        'period' => 'Overpayment Period',
    ],
 
];