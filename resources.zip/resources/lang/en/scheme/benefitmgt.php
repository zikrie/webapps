<?php
 
return [

     'title' => 'Benefit Management Results',

     'attr' => [
    	
        'approved_date' => 'Benefit Approved Date',
        'approved_by' => 'Benefit Approved By',
        'remarks' => 'Remarks',
    ],
 
];