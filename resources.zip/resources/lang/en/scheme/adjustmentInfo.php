<?php
 
return [

     'title' => 'Adjustment Information',

     'attr' => [
    	
        'effective_from' => 'Effective Date From',
        'effective_to' => 'Effective Date To',
        'cost_living' => 'Cost of Living Increment (%)',
        'adjustment_FHULK' => 'Adjustment FHULK',
    ],
 
];