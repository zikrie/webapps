<?php
 
return [

	'title' => 'Payment Option',


    'attr' => [

        'huk_payment_option' => 'HUK Payment Option',
        'date_payment_option' => 'Date Payment Option',
        'updatedby' => 'Updated by',
        'updated_date' => 'Updated Date',
        'approvedby' => 'Approved by',
        'approved_date' => 'Approved Date'
    	
    ],

    'save' => 'SAVE',
    'cancel' => 'Cancel',
    'clear' => 'Clear',
    'submit' => 'SUBMIT',
    'preview'=>'PREVIEW',
 
];