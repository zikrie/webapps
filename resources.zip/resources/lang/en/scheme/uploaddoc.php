<?php
 
return [

	'title' => 'Upload Document',

    'attr' => [
    	
        'docdesc' => 'Document Description',
        'docpath' => 'Document Path',
        'view' => 'View',
        'delete' => 'Delete',
        'remove' => 'Remove',
        'date' => 'Date',
        
    ],

    'uploadall' => 'UPLOAD ALL',
    'adddoc' => 'ADD DOCUMENT',
    'clear' => 'CLEAR',
 
];