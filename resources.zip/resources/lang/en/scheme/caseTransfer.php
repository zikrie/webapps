<?php
 
return [

	'title' => 'Case Transfer',

    'attr' => [
    	
        'transfer' => 'Transfer',
        'remark' => 'Remark',
        'origin' => 'Origin ',
        'current' => 'Semasa',
 
    ],

    'save' => 'Save',
    'cancel' => 'Cancel',
    'clear' => 'Clear',
    'submit' => 'Submit',
    'view'=> 'View',
 
];

