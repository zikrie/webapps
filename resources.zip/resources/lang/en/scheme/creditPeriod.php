<?php
 
return [

	'title' => 'Credit Period',
    


    'attr' => [
    	
        'hus_notice_id' => 'HUS Notice ID',
        'start_date' => 'HUS Start Date',
        'end_date' => 'HUS End Date',
        'total_months' => 'Total Months',
        'overall_months' => 'Total Overall Months',
        
 
    ],

    'save' => 'Save',
    'cancel' => 'Cancel',
    'clear' => 'Clear',
    'submit' => 'Submit',
    'view'=> 'View',
 
];

