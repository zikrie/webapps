<?php
 
return [

	'title' => 'Case Fact',
    


    'attr' => [
    	
        'case_facts' => 'Case Facts',
        'recommendation' => 'Recommendation',
        'reviews_approval' => 'Reviews of Approval',
        'investigator_name' => 'Investigator Name',
        'date' => 'Date',
        'comment' => 'Comment',
        

    ],

    'save' => 'SAVE',
    'cancel' => 'CANCEL',
    'clear' => 'CLEAR',
    'submit' => 'SUBMIT',
    'view'=> 'VIEW',
 
];