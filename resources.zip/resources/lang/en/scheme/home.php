<?php
 
return [

    'title' => 'Notification',
    'total_task' => 'Total Task',
    'list_claim' => 'List of Claim',
    'search' => 'Search',
    'select'=>'Select',
    'delete'=>'Delete',
    'no' => 'WB ID',
    'date' => 'Date',
    'aging' => 'Aging',
    'scheme_ref_no' => 'Scheme Ref No.',
    'case_id' => 'Case Id',
    'desc' => 'Description',
    'action' => 'Action',
        'revision_ref_no'=>'Revision Ref No',
        'med_ref_no'=>'Medical Ref No',
        'rtw_ref_no'=>'RTW Ref No',
        'caserefno'=>'Temp Ref No',
        'noticetype'=>'Notice Type',
        'task' => 'Task Inbox',
                'idno' => 'ID No',
                'draft'=> 'Draft',
                'query'=>'Query',
    'check'=>'EN'
                

 
];