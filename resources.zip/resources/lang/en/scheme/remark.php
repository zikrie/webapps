<?php
 
return [

     'title' => 'Adjustment Information',

     'attr' => [
    	
        'date' => 'Date',
        'from' => 'From',
        'to' => 'To',
        'time' => 'Time',
        'remark' => 'Remark',
    ],
 
];