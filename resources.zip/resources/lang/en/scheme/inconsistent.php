<?php
 
return [

	'title' => 'Inconsistent Information',
  'title_justification' => 'Justification Finding',
    
    'attr' => [
    	
       'item' => 'Item',
       'data'=>'Data',
       'review' => 'Review',
       'review_by' => 'Review by',
       'investigation_date' => 'Investigation Date',
       'date' => 'Date',
       'finding_data' => 'Finding Data',
       'justification' => 'Justification/Finding',
       'justify_by' => 'Justify by',

    ],

    'save' => 'Save',
    'cancel' => 'Cancel',
    'clear' => 'Clear',
    'submit' => 'Submit',
    'view'=> 'View',
 
];