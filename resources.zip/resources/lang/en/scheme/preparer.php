<?php
 
return [

	'title' => 'Preparer Information ',

    'attr' => [
    	
        'preparedBy' => 'Prepared By',
        'preparedDate' => 'Prepared Date',
        
    ],
 
];