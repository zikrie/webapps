<?php

return [

	'profile' => 'My Profile',
	'balance' => 'My Balance',
	'inbox' => 'Inbox',
	'account' => 'Account Setting',
	'logout' => 'Logout'
	
];