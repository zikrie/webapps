<?php
 
return [

	'title' => 'Inconsistent Information',
    


    'attr' => [
    	
        'item' => 'Item',
        'data' => 'Data',
        'review' => 'Review',
        'review_by' => 'Review By',
        'justification_finding' => 'Justification Finding',
        'date_investigation' => 'The date of the investigation', 
        'date' => 'Date',
        'data_amendment' => 'Data Amendment',
        'finding_data' => 'Finding Data',
        'justification_finding' => 'Justification/Finding',
        'justify_by' => 'Justify By',
        'time' => 'Masa Kempangan',
        'place' => 'Tempat Kemalangan',
        'accdate' => 'Tarik Kemalangan',
        'type' => 'Bagaimana kemalngan berlaku',
        'how' => 'Bagaimana Kemalnagan berlaku',
        'deathdate' => 'Tarikh kematian',
        'causeofdeath' => 'Sebab Kemation',

        

    ],

    'save' => 'SAVE',
    'cancel' => 'CANCEL',
    'clear' => 'CLEAR',
    'submit' => 'SUBMIT',
    'view'=> 'VIEW',
 
];