<?php
 
return [

	'title' => 'MS Opinion',
    


    'attr' => [
    	
        'opinion_type' => 'Opinion Type',
        'ms_opinion' => 'MS Opinion',

    ],

    'save' => 'Save',
    'cancel' => 'Cancel',
    'clear' => 'Clear',
    'submit' => 'Submit',
 
];