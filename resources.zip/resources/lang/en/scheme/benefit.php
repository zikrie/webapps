<?php
 
return [

	'title' => 'Benefit Management Decision',
    'title_temporary' => 'Temporary Disablement Benefit Decision',
    'interim' => 'Interim',
    


    'attr' => [
    	
        'benefit_approvedate' => 'Benefit Approved Date',
        'benefit_approvedby' => 'Benefit Approved By',
        'remarks' => 'Remarks ',

         //interim
        'amount' => 'Amount',
 
    ],

    'save' => 'Save',
    'cancel' => 'Cancel',
    'clear' => 'Clear',
    'submit' => 'Submit',
    'view'=> 'View',
 
];

