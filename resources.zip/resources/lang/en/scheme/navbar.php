<?php
 
return [

	'new_claim' => 'New Claim',
	'upload_doc' => 'Upload Document',
	'home' => 'My BeAMS',
	'ob_profile' => 'OB Profile',
	'claim_info' => 'Claim Info',
 
];