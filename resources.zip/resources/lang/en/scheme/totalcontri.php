<?php
 
return [
  'title'=>'Total Contribution',
    'attr' => [

      'employer_code' => 'Employer Code',
      'employer_name' => 'Employer Name',
      'no' => 'No',
      'year' => 'Year',
      'employer_monthly_contribution' => 'Employer Monthly Contribution',
      'no_contribution' => 'No Of Contribution',
      'totalmonths_contributed' => 'Total Contribution',
      'month_1' =>'January',
      'month_2' =>'February',
      'month_3' =>'March',
      'month_4' =>'April',
      'month_5' =>'May',
      'month_6' =>'June',
      'month_7' =>'July',
      'month_8' =>'August',
      'month_9' =>'September',
      'month_10' =>'October',
      'month_11' =>'November',
      'month_12' =>'December',
       
    ],

 
];