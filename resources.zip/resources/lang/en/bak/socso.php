<?php
 
return [

	'title' => 'Preferred Socso Office ',

    'attr' => [
    	
        'city' => 'City',
        'state' => 'State',
        'city_origin' => ' City (Origin)',
        'state_origin' => 'State (Origin)',
        'details' => 'If there is a change of office',
        
    ],

    'save' => 'Save',
    'cancel' => 'Cancel',
    'clear' => 'Clear',
 
];