<?php

return [

   'january' => 'January',
   'february' => 'February',
   'march' => 'March',
   'april' => 'April',
   'may' => 'May',
   'june' => 'June',
   'july' => 'July',
   'august' => 'August',
   'september' => 'September',
   'october' => 'Obtober',
   'november' => 'November',
   'december' => 'December',
];