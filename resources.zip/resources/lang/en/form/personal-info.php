<?php

// For Personal info

return [

          'name' => 'Name',
          'id_no' => 'Identification No',
          'id_type' => 'Identification Type',
          'race' => 'Race',
          'date_birth' => 'Date of Birth',
          'gender' => 'Gender',
	
];