<?php

// For Personal info

return [

          'address' => 'Address',
          'postcode' => 'Postcode',
          'city' => 'City',
          'state' => 'State',
          'tel_no' => 'Telephone No',
          'mobile_no' => 'Mobile No',
          'email' => 'Email Address',
          'nationality' => 'Nationality',
	
];