<?php

// For button on every page for all modules

return [

	'save' => 'SAVE',
	'save_next' => 'SAVE & NEXT',
	'cancel' => 'CANCEL',
	'next' => 'NEXT',
	'previous' => 'PREVIOUS',
	'reset' => 'RESET',
	'back' => 'BACK',
	'close' => 'CLOSE',
	'ok' => 'OK',
	'adddoc' => 'ADD DOCUMENT',
	
];